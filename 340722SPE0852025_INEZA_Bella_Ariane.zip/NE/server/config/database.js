module.exports = {
  development: {
    username: 'postgres', 
    password: '12345678', 
    database: 'parking_db',
    host: 'localhost',
    port: 5432,
    dialect: 'postgres',
    logging: false
  }
};