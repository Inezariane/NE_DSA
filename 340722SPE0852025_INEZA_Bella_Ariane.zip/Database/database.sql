--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: enum_Users_role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_Users_role" AS ENUM (
    'admin',
    'user'
);


ALTER TYPE public."enum_Users_role" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ParkingRecords; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ParkingRecords" (
    id uuid NOT NULL,
    "vehicleId" uuid NOT NULL,
    "parkingId" uuid NOT NULL,
    "userId" uuid NOT NULL,
    "entryDateTime" timestamp with time zone NOT NULL,
    "exitDateTime" timestamp with time zone,
    "chargedAmount" numeric(10,2) DEFAULT 0 NOT NULL,
    "ticketNumber" character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ParkingRecords" OWNER TO postgres;

--
-- Name: Parkings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Parkings" (
    id uuid NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    "totalSpaces" integer NOT NULL,
    "availableSpaces" integer NOT NULL,
    location character varying(255) NOT NULL,
    "feePerHour" numeric(10,2) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Parkings" OWNER TO postgres;

--
-- Name: Users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Users" (
    id uuid NOT NULL,
    "firstName" character varying(255) NOT NULL,
    "lastName" character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    role public."enum_Users_role" DEFAULT 'user'::public."enum_Users_role",
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Users" OWNER TO postgres;

--
-- Name: Vehicles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Vehicles" (
    id uuid NOT NULL,
    "plateNumber" character varying(255) NOT NULL,
    "userId" uuid NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Vehicles" OWNER TO postgres;

--
-- Data for Name: ParkingRecords; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ParkingRecords" (id, "vehicleId", "parkingId", "userId", "entryDateTime", "exitDateTime", "chargedAmount", "ticketNumber", "createdAt", "updatedAt") FROM stdin;
a2ce2b95-e277-4b1d-b96f-bf10ca937065	80984f40-a872-4a6a-b8a5-d107ad3ae245	82d04dbd-2827-42c1-b93f-0d138a2ecf9e	e00ae8b7-036f-44d4-bbe7-e12ce9dc0e9e	2025-05-20 23:05:00-07	2025-05-21 17:06:00-07	901.67	TICKET-4B690541	2025-05-21 17:06:02.688-07	2025-05-21 17:06:34.115-07
f1d6f936-a392-4554-b2e6-212e3c4c03a3	a9caa839-fbb2-4651-952b-45a4532a03c8	0a311f87-2799-4d2f-9271-189d6a366b28	0e9f3d76-1d3c-4c94-8fb8-e158aa9b8ef5	2025-05-21 17:30:00-07	\N	0.00	TICKET-5A846DC7	2025-05-21 17:30:39.433-07	2025-05-21 17:30:39.433-07
\.


--
-- Data for Name: Parkings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Parkings" (id, code, name, "totalSpaces", "availableSpaces", location, "feePerHour", "createdAt", "updatedAt") FROM stdin;
82d04dbd-2827-42c1-b93f-0d138a2ecf9e	P001	Kigali Parking	12	12	Kigali	100.00	2025-05-21 17:05:42.93-07	2025-05-21 17:06:34.116-07
0a311f87-2799-4d2f-9271-189d6a366b28	P007	Kigali Parking	20	19	Kigali	100.00	2025-05-21 17:30:13.651-07	2025-05-21 17:30:39.478-07
\.


--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Users" (id, "firstName", "lastName", email, password, role, "createdAt", "updatedAt") FROM stdin;
e00ae8b7-036f-44d4-bbe7-e12ce9dc0e9e	Ariane	Bella	ariane@gmail.com	$2a$10$3iaBODUdCmWPKJWWptwupeN3c4c0a6VgnAKJwHmjkvJO62xnS1lbe	user	2025-05-21 17:03:30.117-07	2025-05-21 17:03:30.117-07
fd55acc0-4c70-46fa-998a-3a9f907d83ee	angel	mbabazi	mbabazi@gmail.com	$2a$10$7kIoBTeRzT6fra6ZdNqnSOXZbMsFVh1S9TjmaJQjzMmqzuL0VcGZu	user	2025-05-21 17:03:54.403-07	2025-05-21 17:03:54.403-07
1da31328-f7f8-4a96-8f86-1535d061fe0d	leslie	uwineza	uwineza@gmail.com	$2a$10$i0wZlfwDzutVN5K0QxnyZuD7SPfKumf3sk8E5jtKk81Td7eR5CAKa	user	2025-05-21 17:04:14.713-07	2025-05-21 17:04:14.713-07
e86ae371-d73c-40b4-b68e-044c1ffd09e1	admin	pms	admin@gmail.com	$2a$10$W6xKdCiGHoaLBppm.tBs1ODx7TTaFQ0s1cBIIR/yfb.fNehsgU4lO	admin	2025-05-21 17:04:30.763-07	2025-05-21 17:04:30.763-07
0e9f3d76-1d3c-4c94-8fb8-e158aa9b8ef5	Ariane	Ineza	arianeineza@gmail.com	$2a$10$VpETSygoxFHCqY7T2HBE3ul44kxRiu5C/CJduF5amAr0eNCrf2xuC	user	2025-05-21 17:28:56.824-07	2025-05-21 17:28:56.824-07
\.


--
-- Data for Name: Vehicles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Vehicles" (id, "plateNumber", "userId", "createdAt", "updatedAt") FROM stdin;
80984f40-a872-4a6a-b8a5-d107ad3ae245	RAA212A	e00ae8b7-036f-44d4-bbe7-e12ce9dc0e9e	2025-05-21 17:04:57.044-07	2025-05-21 17:04:57.044-07
ff9f839a-d78f-478a-b552-c7a2b67f1713	RAA212B	e00ae8b7-036f-44d4-bbe7-e12ce9dc0e9e	2025-05-21 17:05:03.38-07	2025-05-21 17:05:03.38-07
a9caa839-fbb2-4651-952b-45a4532a03c8	RAA345B	0e9f3d76-1d3c-4c94-8fb8-e158aa9b8ef5	2025-05-21 17:29:29.989-07	2025-05-21 17:29:29.989-07
\.


--
-- Name: ParkingRecords ParkingRecords_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ParkingRecords"
    ADD CONSTRAINT "ParkingRecords_pkey" PRIMARY KEY (id);


--
-- Name: ParkingRecords ParkingRecords_ticketNumber_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ParkingRecords"
    ADD CONSTRAINT "ParkingRecords_ticketNumber_key" UNIQUE ("ticketNumber");


--
-- Name: ParkingRecords ParkingRecords_ticketNumber_key1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ParkingRecords"
    ADD CONSTRAINT "ParkingRecords_ticketNumber_key1" UNIQUE ("ticketNumber");


--
-- Name: ParkingRecords ParkingRecords_ticketNumber_key2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ParkingRecords"
    ADD CONSTRAINT "ParkingRecords_ticketNumber_key2" UNIQUE ("ticketNumber");


--
-- Name: ParkingRecords ParkingRecords_ticketNumber_key3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ParkingRecords"
    ADD CONSTRAINT "ParkingRecords_ticketNumber_key3" UNIQUE ("ticketNumber");


--
-- Name: Parkings Parkings_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parkings"
    ADD CONSTRAINT "Parkings_code_key" UNIQUE (code);


--
-- Name: Parkings Parkings_code_key1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parkings"
    ADD CONSTRAINT "Parkings_code_key1" UNIQUE (code);


--
-- Name: Parkings Parkings_code_key2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parkings"
    ADD CONSTRAINT "Parkings_code_key2" UNIQUE (code);


--
-- Name: Parkings Parkings_code_key3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parkings"
    ADD CONSTRAINT "Parkings_code_key3" UNIQUE (code);


--
-- Name: Parkings Parkings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Parkings"
    ADD CONSTRAINT "Parkings_pkey" PRIMARY KEY (id);


--
-- Name: Users Users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key" UNIQUE (email);


--
-- Name: Users Users_email_key1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key1" UNIQUE (email);


--
-- Name: Users Users_email_key2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key2" UNIQUE (email);


--
-- Name: Users Users_email_key3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key3" UNIQUE (email);


--
-- Name: Users Users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_pkey" PRIMARY KEY (id);


--
-- Name: Vehicles Vehicles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Vehicles"
    ADD CONSTRAINT "Vehicles_pkey" PRIMARY KEY (id);


--
-- Name: Vehicles Vehicles_plateNumber_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Vehicles"
    ADD CONSTRAINT "Vehicles_plateNumber_key" UNIQUE ("plateNumber");


--
-- Name: Vehicles Vehicles_plateNumber_key1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Vehicles"
    ADD CONSTRAINT "Vehicles_plateNumber_key1" UNIQUE ("plateNumber");


--
-- Name: Vehicles Vehicles_plateNumber_key2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Vehicles"
    ADD CONSTRAINT "Vehicles_plateNumber_key2" UNIQUE ("plateNumber");


--
-- Name: Vehicles Vehicles_plateNumber_key3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Vehicles"
    ADD CONSTRAINT "Vehicles_plateNumber_key3" UNIQUE ("plateNumber");


--
-- Name: parking_records_ticket_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX parking_records_ticket_number ON public."ParkingRecords" USING btree ("ticketNumber");


--
-- Name: parking_records_vehicle_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX parking_records_vehicle_id ON public."ParkingRecords" USING btree ("vehicleId");


--
-- Name: vehicles_plate_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX vehicles_plate_number ON public."Vehicles" USING btree ("plateNumber");


--
-- Name: ParkingRecords ParkingRecords_parkingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ParkingRecords"
    ADD CONSTRAINT "ParkingRecords_parkingId_fkey" FOREIGN KEY ("parkingId") REFERENCES public."Parkings"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ParkingRecords ParkingRecords_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ParkingRecords"
    ADD CONSTRAINT "ParkingRecords_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ParkingRecords ParkingRecords_vehicleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ParkingRecords"
    ADD CONSTRAINT "ParkingRecords_vehicleId_fkey" FOREIGN KEY ("vehicleId") REFERENCES public."Vehicles"(id) ON UPDATE CASCADE;


--
-- Name: Vehicles Vehicles_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Vehicles"
    ADD CONSTRAINT "Vehicles_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

